#!/bin/sh

"java" -jar "/usr/local/solr-4.10.1/example/start.jar" STOP.PORT=7983 STOP.KEY=solrrocks --stop
